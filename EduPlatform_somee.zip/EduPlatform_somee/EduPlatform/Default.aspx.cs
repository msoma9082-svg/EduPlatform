﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace EduPlatform
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) LoadCourses("");
        }

        void ShowTable(DataTable dt)
        {
            rptCourses.DataSource = dt;
            rptCourses.DataBind();
            lblNone.Visible = (dt.Rows.Count == 0);
        }

        void LoadCourses(string q)
        {
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT Courses.Id, Courses.Title, Courses.Description, Courses.Price, Categories.CategoryName " +
                    "FROM Courses INNER JOIN Categories ON Courses.CategoryId=Categories.Id " +
                    "WHERE Courses.Title LIKE @q ORDER BY Courses.Id", con);
                da.SelectCommand.Parameters.AddWithValue("@q", "%" + q + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);
                ShowTable(dt);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadCourses(txtSearch.Text.Trim());
        }

        protected void btnMy_Click(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT Courses.Id, Courses.Title, Courses.Description, Courses.Price, Categories.CategoryName " +
                    "FROM Enrollments INNER JOIN Courses ON Enrollments.CourseId=Courses.Id " +
                    "INNER JOIN Categories ON Courses.CategoryId=Categories.Id " +
                    "WHERE Enrollments.StudentId=@s ORDER BY Courses.Id", con);
                da.SelectCommand.Parameters.AddWithValue("@s", Session["UserId"]);
                DataTable dt = new DataTable();
                da.Fill(dt);
                ShowTable(dt);
            }
        }
    }
}
