﻿using System;
using System.Data.SqlClient;

namespace EduPlatform
{
    public partial class Register : System.Web.UI.Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();

                SqlCommand check = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Email=@Email", con);
                check.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                {
                    lblMsg.Text = "الايميل ده مسجل من قبل";
                    return;
                }

                SqlCommand cmd = new SqlCommand("INSERT INTO Users (Name, Email, Password, Role) VALUES (@Name, @Email, @Pass, 'Student')", con);
                cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@Pass", Db.Hash(txtPass.Text));
                cmd.ExecuteNonQuery();
            }
            Response.Redirect("~/Login.aspx");
        }
    }
}
