﻿<%@ Page Title="الرئيسية" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="EduPlatform.Default" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<h2>مرحباً بيك في منصة التعلم</h2>
<asp:TextBox ID="txtSearch" runat="server" CssClass="form-control search" placeholder="ابحث عن كورس..."></asp:TextBox>
<asp:Button ID="btnSearch" runat="server" Text="بحث" CssClass="btn btn-purple" OnClick="btnSearch_Click" />
<asp:Button ID="btnMy" runat="server" Text="كورساتي فقط" CssClass="btn btn-orange" OnClick="btnMy_Click" />
<br /><br />
<asp:Label ID="lblNone" runat="server" Text="ما في كورسات للعرض" Visible="false" ForeColor="Gray"></asp:Label>
<asp:Repeater ID="rptCourses" runat="server">
<ItemTemplate>
<div class="card">
<h3 style="color:#5B2C6F"><%#: Eval("Title") %></h3>
<p><%#: Eval("Description") %></p>
<p><b>السعر:</b> <%#: Eval("Price", "{0:0.##}") %> جنيه سوداني | <b>القسم:</b> <%#: Eval("CategoryName") %></p>
<a href='CourseDetails.aspx?Id=<%# Eval("Id") %>' class="btn btn-purple">التفاصيل</a>
</div>
</ItemTemplate>
</asp:Repeater>
</asp:Content>
