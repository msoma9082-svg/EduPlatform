﻿<%@ Page Title="دخول" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="EduPlatform.Login" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card narrow">
<h2>تسجيل الدخول</h2>
<label>الايميل</label>
<asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" placeholder="اكتب ايميلك"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="* لازم تكتب الايميل" CssClass="err" Display="Dynamic"></asp:RequiredFieldValidator>
<asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" ErrorMessage="* شكل الايميل غلط" CssClass="err" Display="Dynamic"></asp:RegularExpressionValidator>
<label>كلمة المرور</label>
<asp:TextBox ID="txtPass" runat="server" TextMode="Password" CssClass="form-control" placeholder="كلمة المرور"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvPass" runat="server" ControlToValidate="txtPass" ErrorMessage="* لازم تكتب كلمة المرور" CssClass="err" Display="Dynamic"></asp:RequiredFieldValidator>
<br />
<asp:Button ID="btnLogin" runat="server" Text="دخول" CssClass="btn btn-purple" OnClick="btnLogin_Click" />
<br /><br /><a href="Register.aspx">ما عندك حساب؟ سجل هنا</a><br />
<asp:ValidationSummary ID="vsLogin" runat="server" ForeColor="Red" HeaderText="في مشكلة، راجع:" />
<asp:Label ID="lblMsg" runat="server" ForeColor="Red"></asp:Label>
</div>
</asp:Content>
