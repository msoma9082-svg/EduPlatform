﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.UI.WebControls;

namespace EduPlatform
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // الصفحة للمدرب فقط
            if (Session["Role"] == null || !string.Equals(Session["Role"].ToString(), "Admin", StringComparison.OrdinalIgnoreCase))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }
            if (!IsPostBack)
            {
                LoadCategories();
                LoadCourses();
            }
        }

        void LoadCategories()
        {
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT Id, CategoryName FROM Categories ORDER BY Id", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                ddlCat.DataSource = dt;
                ddlCat.DataTextField = "CategoryName";
                ddlCat.DataValueField = "Id";
                ddlCat.DataBind();
            }
        }

        void LoadCourses()
        {
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT Courses.Id, Courses.Title, Courses.Price, Categories.CategoryName " +
                    "FROM Courses INNER JOIN Categories ON Courses.CategoryId=Categories.Id ORDER BY Courses.Id DESC", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvCourses.DataSource = dt;
                gvCourses.DataBind();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;
            if (ddlCat.Items.Count == 0) return;

            decimal price;
            if (!decimal.TryParse(txtPrice.Text.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out price))
            {
                lblMsg.ForeColor = System.Drawing.Color.Red;
                lblMsg.Text = "السعر لازم يكون رقم";
                return;
            }

            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Courses (Title, Description, Price, CategoryId) VALUES (@Title, @Desc, @Price, @Cat)", con);
                cmd.Parameters.AddWithValue("@Title", txtTitle.Text.Trim());
                cmd.Parameters.AddWithValue("@Desc", txtDesc.Text.Trim());
                SqlParameter p = cmd.Parameters.Add("@Price", SqlDbType.Decimal);
                p.Precision = 10;
                p.Scale = 2;
                p.Value = price;
                cmd.Parameters.AddWithValue("@Cat", Convert.ToInt32(ddlCat.SelectedValue));
                cmd.ExecuteNonQuery();
            }

            txtTitle.Text = "";
            txtDesc.Text = "";
            txtPrice.Text = "";
            lblMsg.ForeColor = System.Drawing.Color.Green;
            lblMsg.Text = "تمت إضافة الكورس بنجاح";
            LoadCourses();
        }

        protected void gvCourses_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Del") return;

            int id = Convert.ToInt32(e.CommandArgument);

            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();
                SqlTransaction tr = con.BeginTransaction();
                try
                {
                    // لازم نحذف الاشياء المرتبطة بالكورس اول (Foreign Key)
                    DeleteById(con, tr, "DELETE FROM Enrollments WHERE CourseId=@id", id);
                    DeleteById(con, tr, "DELETE FROM Lessons WHERE CourseId=@id", id);
                    DeleteById(con, tr, "DELETE FROM Courses WHERE Id=@id", id);
                    tr.Commit();
                }
                catch
                {
                    tr.Rollback();
                    throw;
                }
            }
            lblMsg.ForeColor = System.Drawing.Color.Green;
            lblMsg.Text = "تم حذف الكورس";
            LoadCourses();
        }

        void DeleteById(SqlConnection con, SqlTransaction tr, string sql, int id)
        {
            SqlCommand cmd = new SqlCommand(sql, con, tr);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }
    }
}
