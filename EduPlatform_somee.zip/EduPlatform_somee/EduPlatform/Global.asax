﻿<%@ Application Codebehind="Global.asax.cs" Inherits="EduPlatform.Global" Language="C#" %>
