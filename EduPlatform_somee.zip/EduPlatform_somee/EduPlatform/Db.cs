﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace EduPlatform
{
    public static class Db
    {
        public static string InitError = null;

        public static string ConnString
        {
            get { return ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString; }
        }

        // تشفير كلمة المرور (SHA256)
        public static string Hash(string text)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(text));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        const string SchemaSql = @"
IF OBJECT_ID('dbo.Users','U') IS NULL
CREATE TABLE dbo.Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    Role NVARCHAR(20) NOT NULL DEFAULT 'Student'
);
IF OBJECT_ID('dbo.Categories','U') IS NULL
CREATE TABLE dbo.Categories (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL
);
IF OBJECT_ID('dbo.Courses','U') IS NULL
CREATE TABLE dbo.Courses (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(MAX) NULL,
    Price DECIMAL(10,2) NOT NULL DEFAULT 0,
    CategoryId INT NOT NULL FOREIGN KEY REFERENCES dbo.Categories(Id)
);
IF OBJECT_ID('dbo.Lessons','U') IS NULL
CREATE TABLE dbo.Lessons (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CourseId INT NOT NULL FOREIGN KEY REFERENCES dbo.Courses(Id),
    Title NVARCHAR(200) NOT NULL,
    Content NVARCHAR(MAX) NULL,
    OrderIndex INT NOT NULL
);
IF OBJECT_ID('dbo.Enrollments','U') IS NULL
CREATE TABLE dbo.Enrollments (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT NOT NULL FOREIGN KEY REFERENCES dbo.Users(Id),
    CourseId INT NOT NULL FOREIGN KEY REFERENCES dbo.Courses(Id),
    Progress INT NOT NULL DEFAULT 0
);";

        const string SeedSql = @"
IF NOT EXISTS (SELECT 1 FROM dbo.Categories)
BEGIN
    INSERT INTO dbo.Categories (CategoryName) VALUES (N'برمجة'), (N'تصميم'), (N'لغات');
    INSERT INTO dbo.Users (Name, Email, Password, Role) VALUES
        (N'admin', N'admin@gmail.com', @p, N'Admin'),
        (N'sima', N'sima@gmail.com', @p, N'Student');
    INSERT INTO dbo.Courses (Title, Description, Price, CategoryId) VALUES
        (N'أساسيات C#', N'كورس للمبتدئين في لغة C#', 5000, (SELECT TOP 1 Id FROM dbo.Categories WHERE CategoryName=N'برمجة')),
        (N'تصميم واجهات', N'تعلم أساسيات تصميم الواجهات', 7000, (SELECT TOP 1 Id FROM dbo.Categories WHERE CategoryName=N'تصميم')),
        (N'اللغة الإنجليزية للمبتدئين', N'كورس لتعلم أساسيات اللغة الإنجليزية', 3000, (SELECT TOP 1 Id FROM dbo.Categories WHERE CategoryName=N'لغات'));
    INSERT INTO dbo.Lessons (CourseId, Title, Content, OrderIndex) VALUES
        ((SELECT Id FROM dbo.Courses WHERE Title=N'أساسيات C#'), N'الدرس الأول - مقدمة', N'هنا شرح الدرس الأول: ما هي لغة C# وكيف نبدأ.', 1),
        ((SELECT Id FROM dbo.Courses WHERE Title=N'أساسيات C#'), N'الدرس الثاني - المتغيرات', N'هنا شرح الدرس الثاني: المتغيرات وأنواع البيانات.', 2),
        ((SELECT Id FROM dbo.Courses WHERE Title=N'أساسيات C#'), N'الدرس الثالث - الشروط', N'هنا شرح الدرس الثالث: جمل if و else.', 3),
        ((SELECT Id FROM dbo.Courses WHERE Title=N'تصميم واجهات'), N'الدرس الأول - الألوان', N'هنا شرح اختيار الألوان في التصميم.', 1),
        ((SELECT Id FROM dbo.Courses WHERE Title=N'تصميم واجهات'), N'الدرس الثاني - الخطوط', N'هنا شرح اختيار الخطوط وتنسيق النص.', 2),
        ((SELECT Id FROM dbo.Courses WHERE Title=N'اللغة الإنجليزية للمبتدئين'), N'الدرس الأول - الحروف', N'هنا شرح الحروف والنطق.', 1),
        ((SELECT Id FROM dbo.Courses WHERE Title=N'اللغة الإنجليزية للمبتدئين'), N'الدرس الثاني - التحية', N'هنا شرح جمل التحية.', 2);
END";

        public static void EnsureDatabase()
        {
            try
            {
                // لو القاعدة موجودة وبنقدر نفتحها (زي في somee) ما بنحاول ننشئها
                bool exists = false;
                try
                {
                    using (SqlConnection test = new SqlConnection(ConnString))
                    {
                        test.Open();
                        exists = true;
                    }
                }
                catch
                {
                    exists = false;
                }

                // على LocalDB (جهازك): اول مرة بننشئ القاعدة نفسها
                if (!exists)
                {
                    SqlConnectionStringBuilder csb = new SqlConnectionStringBuilder(ConnString);
                    string dbName = csb.InitialCatalog;
                    csb.InitialCatalog = "master";

                    using (SqlConnection master = new SqlConnection(csb.ConnectionString))
                    {
                        master.Open();
                        SqlCommand create = new SqlCommand("IF DB_ID(@n) IS NULL EXEC('CREATE DATABASE [' + @n + ']')", master);
                        create.Parameters.AddWithValue("@n", dbName);
                        create.ExecuteNonQuery();
                    }
                }

                using (SqlConnection con = new SqlConnection(ConnString))
                {
                    con.Open();
                    new SqlCommand(SchemaSql, con).ExecuteNonQuery();
                    SqlCommand seed = new SqlCommand(SeedSql, con);
                    seed.Parameters.AddWithValue("@p", Hash("1234"));
                    seed.ExecuteNonQuery();
                }
                InitError = null;
            }
            catch (Exception ex)
            {
                InitError = ex.Message;
            }
        }
    }
}
