﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace EduPlatform
{
    public partial class CourseDetails : System.Web.UI.Page
    {
        int CourseId
        {
            get
            {
                int id;
                return int.TryParse(Request.QueryString["Id"], out id) ? id : 0;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (CourseId == 0)
            {
                Response.Redirect("~/Default.aspx");
                return;
            }
            if (!IsPostBack) LoadAll();
        }

        // تقدم الطالب في الكورس، او null لو ما مسجل
        int? GetProgress(SqlConnection con)
        {
            if (Session["UserId"] == null) return null;
            SqlCommand cmd = new SqlCommand("SELECT Progress FROM Enrollments WHERE StudentId=@s AND CourseId=@c", con);
            cmd.Parameters.AddWithValue("@s", Session["UserId"]);
            cmd.Parameters.AddWithValue("@c", CourseId);
            object o = cmd.ExecuteScalar();
            if (o == null || o == DBNull.Value) return null;
            return Convert.ToInt32(o);
        }

        void LoadAll()
        {
            bool found = false;
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter("SELECT Title, Description, Price FROM Courses WHERE Id=@c", con);
                da.SelectCommand.Parameters.AddWithValue("@c", CourseId);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    found = true;
                    DataRow r = dt.Rows[0];
                    lblTitle.Text = Server.HtmlEncode(r["Title"].ToString());
                    lblDesc.Text = Server.HtmlEncode(r["Description"].ToString());
                    lblPrice.Text = r["Price"] == DBNull.Value ? "0" : Convert.ToDecimal(r["Price"]).ToString("0.##");

                    int? progress = GetProgress(con);
                    lblProgress.Text = (progress ?? 0).ToString();
                    btnEnroll.Visible = (progress == null);
                    if (progress != null && lblMsg.Text == "")
                    {
                        lblMsg.ForeColor = System.Drawing.Color.Green;
                        lblMsg.Text = "أنت مسجل في هذا الكورس";
                    }
                    lblCert.Text = (progress != null && progress >= 100) ? "مبروك! أكملت الكورس وحصلت على الشهادة" : "";

                    SqlDataAdapter dl = new SqlDataAdapter("SELECT Title, Content, OrderIndex FROM Lessons WHERE CourseId=@c ORDER BY OrderIndex", con);
                    dl.SelectCommand.Parameters.AddWithValue("@c", CourseId);
                    DataTable lessons = new DataTable();
                    dl.Fill(lessons);
                    rptLessons.DataSource = lessons;
                    rptLessons.DataBind();
                }
            }
            if (!found) Response.Redirect("~/Default.aspx");
        }

        protected void btnEnroll_Click(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();
                if (GetProgress(con) == null)
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Enrollments (StudentId, CourseId, Progress) VALUES (@s, @c, 0)", con);
                    cmd.Parameters.AddWithValue("@s", Session["UserId"]);
                    cmd.Parameters.AddWithValue("@c", CourseId);
                    cmd.ExecuteNonQuery();
                }
            }
            lblMsg.ForeColor = System.Drawing.Color.Green;
            lblMsg.Text = "تم التسجيل في الكورس بنجاح";
            LoadAll();
        }

        protected void rptLessons_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName != "Done") return;

            if (Session["UserId"] == null)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();
                if (GetProgress(con) == null)
                {
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                    lblMsg.Text = "سجل في الكورس اولا";
                }
                else
                {
                    int orderIndex = Convert.ToInt32(e.CommandArgument);

                    SqlCommand cnt = new SqlCommand("SELECT COUNT(*) FROM Lessons WHERE CourseId=@c", con);
                    cnt.Parameters.AddWithValue("@c", CourseId);
                    int total = Convert.ToInt32(cnt.ExecuteScalar());

                    if (total > 0)
                    {
                        int newProgress = Math.Min(100, orderIndex * 100 / total);

                        // التقدم يزيد بس ما بنقص
                        SqlCommand upd = new SqlCommand("UPDATE Enrollments SET Progress=@p WHERE StudentId=@s AND CourseId=@c AND Progress<@p", con);
                        upd.Parameters.AddWithValue("@p", newProgress);
                        upd.Parameters.AddWithValue("@s", Session["UserId"]);
                        upd.Parameters.AddWithValue("@c", CourseId);
                        upd.ExecuteNonQuery();
                    }
                    lblMsg.Text = "";
                }
            }
            LoadAll();
        }
    }
}
