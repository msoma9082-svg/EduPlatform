﻿<%@ Page Title="تسجيل" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Register.aspx.cs" Inherits="EduPlatform.Register" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card narrow">
<h2>انشاء حساب</h2>
<label>اسم المستخدم</label>
<asp:TextBox ID="txtName" runat="server" CssClass="form-control" placeholder="مثلا: sima"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvName" runat="server" ControlToValidate="txtName" ErrorMessage="* لازم تكتب الاسم" CssClass="err" Display="Dynamic"></asp:RequiredFieldValidator>
<label>الايميل</label>
<asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" placeholder="مثلا: sima@gmail.com"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="* لازم تكتب الايميل" CssClass="err" Display="Dynamic"></asp:RequiredFieldValidator>
<asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" ErrorMessage="* شكل الايميل غلط، لازم يكون زي sima@gmail.com" CssClass="err" Display="Dynamic"></asp:RegularExpressionValidator>
<label>كلمة المرور</label>
<asp:TextBox ID="txtPass" runat="server" TextMode="Password" CssClass="form-control" placeholder="4 حروف وفوق"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvPass" runat="server" ControlToValidate="txtPass" ErrorMessage="* لازم تكتب كلمة المرور" CssClass="err" Display="Dynamic"></asp:RequiredFieldValidator>
<asp:RegularExpressionValidator ID="revPass" runat="server" ControlToValidate="txtPass" ValidationExpression=".{4,}" ErrorMessage="* كلمة المرور لازم تكون 4 حروف او اكتر" CssClass="err" Display="Dynamic"></asp:RegularExpressionValidator>
<label>تأكيد كلمة المرور</label>
<asp:TextBox ID="txtConfirm" runat="server" TextMode="Password" CssClass="form-control"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvConfirm" runat="server" ControlToValidate="txtConfirm" ErrorMessage="* لازم تكتب تأكيد كلمة المرور" CssClass="err" Display="Dynamic"></asp:RequiredFieldValidator>
<asp:CompareValidator ID="cvPass" runat="server" ControlToValidate="txtConfirm" ControlToCompare="txtPass" ErrorMessage="* كلمة المرور ما متطابقة" CssClass="err" Display="Dynamic"></asp:CompareValidator>
<br />
<asp:Button ID="btnRegister" runat="server" Text="تسجيل" CssClass="btn btn-orange" OnClick="btnRegister_Click" />
<br /><br /><a href="Login.aspx">عندك حساب؟ سجل دخول</a><br />
<asp:ValidationSummary ID="vsRegister" runat="server" ForeColor="Red" HeaderText="في مشكلة، راجع:" />
<asp:Label ID="lblMsg" runat="server" ForeColor="Red"></asp:Label>
</div>
</asp:Content>
