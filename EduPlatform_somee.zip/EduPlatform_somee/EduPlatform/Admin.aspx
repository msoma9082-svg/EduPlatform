﻿<%@ Page Title="لوحة المدرب" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Admin.aspx.cs" Inherits="EduPlatform.Admin" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<h2>لوحة المدرب</h2>
<div class="card">
<h3>إضافة كورس جديد</h3>
<label>اسم الكورس</label>
<asp:TextBox ID="txtTitle" runat="server" CssClass="form-control"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvTitle" runat="server" ControlToValidate="txtTitle" ErrorMessage="* لازم تكتب اسم الكورس" ForeColor="Red" Display="Dynamic"></asp:RequiredFieldValidator>
<label>الوصف</label>
<asp:TextBox ID="txtDesc" runat="server" TextMode="MultiLine" Rows="3" CssClass="form-control"></asp:TextBox>
<label>السعر بالجنيه السوداني</label>
<asp:TextBox ID="txtPrice" runat="server" CssClass="form-control" placeholder="مثلا: 5000"></asp:TextBox>
<asp:RequiredFieldValidator ID="rfvPrice" runat="server" ControlToValidate="txtPrice" ErrorMessage="* لازم تكتب السعر" ForeColor="Red" Display="Dynamic"></asp:RequiredFieldValidator>
<asp:RangeValidator ID="rvPrice" runat="server" ControlToValidate="txtPrice" MinimumValue="0" MaximumValue="100000" Type="Double" ErrorMessage="* السعر لازم يكون رقم بين 0 و 100000 جنيه سوداني" ForeColor="Red" Display="Dynamic"></asp:RangeValidator>
<label>القسم</label>
<asp:DropDownList ID="ddlCat" runat="server" CssClass="form-control"></asp:DropDownList>
<br />
<asp:Button ID="btnSave" runat="server" Text="حفظ الكورس" CssClass="btn btn-purple" OnClick="btnSave_Click" />
<br /><br />
<asp:ValidationSummary ID="vsAdmin" runat="server" ForeColor="Red" HeaderText="في مشكلة، راجع:" />
<asp:Label ID="lblMsg" runat="server" ForeColor="Green"></asp:Label>
</div>
<asp:GridView ID="gvCourses" runat="server" AutoGenerateColumns="False" CssClass="grid" GridLines="None" EmptyDataText="لا توجد كورسات حتى الآن" OnRowCommand="gvCourses_RowCommand">
<Columns>
<asp:BoundField DataField="Title" HeaderText="اسم الكورس" />
<asp:BoundField DataField="CategoryName" HeaderText="القسم" />
<asp:BoundField DataField="Price" HeaderText="السعر (جنيه سوداني)" DataFormatString="{0:0.##}" HtmlEncode="false" />
<asp:TemplateField HeaderText="حذف">
<ItemTemplate>
<asp:LinkButton ID="btnDel" runat="server" Text="حذف" CommandName="Del" CommandArgument='<%# Eval("Id") %>' CausesValidation="false" OnClientClick="return confirm('متأكد من حذف الكورس؟');"></asp:LinkButton>
</ItemTemplate>
</asp:TemplateField>
</Columns>
</asp:GridView>
</asp:Content>
