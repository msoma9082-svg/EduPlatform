﻿<%@ Page Title="تفاصيل الكورس" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="CourseDetails.aspx.cs" Inherits="EduPlatform.CourseDetails" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card">
<h2><asp:Label ID="lblTitle" runat="server"></asp:Label></h2>
<p><asp:Label ID="lblDesc" runat="server"></asp:Label></p>
<p>السعر: <asp:Label ID="lblPrice" runat="server"></asp:Label> جنيه سوداني</p>
<p>التقدم: <asp:Label ID="lblProgress" runat="server"></asp:Label>%</p>
<asp:Button ID="btnEnroll" runat="server" Text="سجل الآن في الكورس" CssClass="btn btn-orange" OnClick="btnEnroll_Click" />
<br /><asp:Label ID="lblMsg" runat="server" ForeColor="Green"></asp:Label>
<br /><asp:Label ID="lblCert" runat="server" ForeColor="Green" Font-Bold="true"></asp:Label>
</div>
<h3 style="color:#5B2C6F">الدروس</h3>
<asp:Repeater ID="rptLessons" runat="server" OnItemCommand="rptLessons_ItemCommand">
<ItemTemplate>
<div class="card">
<b><%#: Eval("Title") %></b><br /><%#: Eval("Content") %><br /><br />
<asp:Button ID="btnDone" runat="server" Text="أكملت الدرس" CommandName="Done" CommandArgument='<%# Eval("OrderIndex") %>' CssClass="btn btn-purple" />
</div>
</ItemTemplate>
</asp:Repeater>
</asp:Content>
