﻿using System;
using System.Data.SqlClient;

namespace EduPlatform
{
    public partial class Login : System.Web.UI.Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            object id = null, name = null, role = null;
            using (SqlConnection con = new SqlConnection(Db.ConnString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Id, Name, Role FROM Users WHERE Email=@Email AND Password=@Pass", con);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@Pass", Db.Hash(txtPass.Text));
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        id = dr["Id"];
                        name = dr["Name"];
                        role = dr["Role"];
                    }
                }
            }

            if (id == null)
            {
                lblMsg.Text = "الايميل او كلمة المرور غلط";
                return;
            }

            Session["UserId"] = id;
            Session["UserName"] = name;
            Session["Role"] = role;

            if (string.Equals(Convert.ToString(role), "Admin", StringComparison.OrdinalIgnoreCase))
                Response.Redirect("~/Admin.aspx");
            else
                Response.Redirect("~/Default.aspx");
        }
    }
}
