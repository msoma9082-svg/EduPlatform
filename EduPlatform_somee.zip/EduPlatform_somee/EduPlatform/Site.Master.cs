﻿using System;
using System.Web;

namespace EduPlatform
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool logged = Session["UserId"] != null;
            bool isAdmin = logged && string.Equals(Convert.ToString(Session["Role"]), "Admin", StringComparison.OrdinalIgnoreCase);

            lnkLogin.Visible = !logged;
            lnkRegister.Visible = !logged;
            lnkLogout.Visible = logged;
            lnkAdmin.Visible = isAdmin;
            lblUser.Text = logged ? "مرحباً، " + HttpUtility.HtmlEncode(Convert.ToString(Session["UserName"])) : "";

            if (Db.InitError != null)
            {
                lblDbError.Visible = true;
                lblDbError.Text = "تعذر تجهيز قاعدة البيانات: " + HttpUtility.HtmlEncode(Db.InitError)
                    + " — تأكد من وجود LocalDB او غيّر Data Source في Web.config.";
            }
        }

        protected void lnkLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/Login.aspx");
        }
    }
}
