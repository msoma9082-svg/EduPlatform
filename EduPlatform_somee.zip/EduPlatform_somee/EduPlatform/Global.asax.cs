﻿using System;

namespace EduPlatform
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            // ينشئ قاعدة البيانات والجداول والبيانات التجريبية اول مرة بس
            Db.EnsureDatabase();
        }
    }
}
